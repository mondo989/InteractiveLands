# Glowbom AI Extensions Guide for ChatGPT

This guide is intended for ChatGPT with Code Interpreter to understand the context of a given project and to provide assistance in generating code for AI extensions.

This repository contains a basic structure for a Custom application along with a special `aiextensions.js` file. This file is designated for the OpenAI model to add or modify code, providing optional features or enhancements to the existing JavaScript project.

## Understanding the Code

- `index.html`: This is the main file for the Custom application. It represents a simple one-screen app.
- `app.js`: This is where you can add the main logic for the app.
- `aiextensions.js`: This is where you can add custom AI extension code. The `GlowbyScreen` object is an example of what can be added here.

## Interactive Features

For tasks that involve calculations or data manipulation, the generated code should include interactive features that allow users to input data and see the results reflected in the UI. The results should be presented in a clear and user-friendly manner.

For example, if the task is to implement a function that performs calculations based on user input, the generated code should include:

1. Input fields for the user to provide the necessary data.
2. A way for the user to trigger the calculation. This could be a button that the user can press to run the function once the necessary data has been inputted.
3. A way to display the results of the calculation in the UI.

The AI extension should handle any necessary error checking and data validation to ensure that the user-provided data is suitable for the calculation. If the data is not suitable, the AI extension should provide clear feedback to the user about what needs to be corrected.

## Additional Guidelines

1. **Problem Statement Understanding**: Understand the problem statement thoroughly before proceeding with the solution. Ask for clarifications if the problem statement isn't clear.
2. **Solution Language**: Confirm the language of the solution. The solution for the current project is expected to be in JavaScript.
3. **Code Testing**: Test the generated code for any syntax or logical errors before delivering the solution. Also, consider different edge cases to ensure the solution is robust.
4. **Performance Considerations**: Provide solutions that are not just correct but also efficient.

## Generating Code for AI Extensions

The process of creating an AI extension involves generating JavaScript code that extends or enhances the existing Custom application. 

Here are the steps to follow:

1. Glowbom users will attach the `code_interpreter.zip` file along with a description of what they want to create (e.g., "a screen with a list of 3 default habits in a calendar format - workout, meditate, drink water").
2. Based on this description, generate JavaScript code within the `GlowbyScreen` object in the `aiextensions.js` file that fits the users' needs and is compatible with the existing codebase. All generated code should be included within the `aiextensions.js` file.
3. Test the generated code for any syntax or logical errors before delivering the solution. Also, consider different edge cases to ensure the solution is robust.
4. Once the code has been tested and confirmed to be working as expected, return the entire updated `aiextensions.js` file content. This is the final output of the task.
5. Return the Entire File: After generating and testing the code, always return the entire updated `aiextensions.js` file content. Do not return only a part of the code or a class name. The entire content of the file is necessary for the user to easily integrate the new code with their existing codebase.

Remember, any code added should be clearly marked with comments for users to understand what has been added or changed.

Happy coding!

Note: After generating and testing the code, always return the entire updated `aiextensions.js` file content. This is the final output of the task.
